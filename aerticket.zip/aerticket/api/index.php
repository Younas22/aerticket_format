<?php

namespace AppRouter;use Exception;use DateTime;use DateInterval;use InvalidArgumentException;class Router{const NO_ROUTE_FOUND_MSG='No route found';private $routes;private $error;private $baseNamespace;private $currentPrefix;private $service=null;public function __construct($error,$baseNamespace=''){$this->routes=[];$this->error=$error;$this->baseNamespace=$baseNamespace==''?'':$baseNamespace.'\\';$this->currentPrefix='';}public function setService($service){$this->service=$service;}public function getService($service){return $this->service;}public function route($method,$regex,$handler){if($method=='*'){$method=['GET','PUT','DELETE','OPTIONS','TRACE','POST','HEAD'];}foreach((array)$method as $m){$this->addRoute($m,$regex,$handler);}return $this;}private function addRoute($method,$regex,$handler){$this->routes[strtoupper($method)][$this->currentPrefix.$regex]=[$handler,$this->service];}public function mount($prefix,callable $routes,$service=false){$previousPrefix=$this->currentPrefix;$this->currentPrefix=$previousPrefix.$prefix;if($service!==false){$previousService=$this->service;$this->service=$service;}$routes($this);$this->currentPrefix=$previousPrefix;if($service!==false){$this->service=$previousService;}return $this;}public function get($regex,$handler){$this->addRoute('GET',$regex,$handler);return $this;}public function post($regex,$handler){$this->addRoute('POST',$regex,$handler);return $this;}public function put($regex,$handler){$this->addRoute('PUT',$regex,$handler);return $this;}public function head($regex,$handler){$this->addRoute('HEAD',$regex,$handler);return $this;}public function delete($regex,$handler){$this->addRoute('DELETE',$regex,$handler);return $this;}public function options($regex,$handler){$this->addRoute('OPTIONS',$regex,$handler);return $this;}public function trace($regex,$handler){$this->addRoute('TRACE',$regex,$handler);return $this;}public function connect($regex,$handler){$this->addRoute('CONNECT',$regex,$handler);return $this;}public function dispatch($method,$path){if(!isset($this->routes[$method])){$params=[$method,$path,404,new HttpRequestException(self::NO_ROUTE_FOUND_MSG)];return $this->call($this->error,$this->service==null?$params:array_merge([$this->service],$params));}else{foreach($this->routes[$method]as $regex=>$route){$len=strlen($regex);if($len>0){$callback=$route[0];$service=isset($route[1])?$route[1]:null;if($regex[0]!='/')$regex='/'.$regex;if($len>1&&$regex[$len-1]=='/')$regex=substr($regex,0,-1);$regex=str_replace('@','\\@',$regex);if(preg_match('@^'.$regex.'$@',$path,$params)){array_shift($params);try{return $this->call($callback,$service==null?$params:array_merge([$service],$params));}catch(HttpRequestException $ex){$params=[$method,$path,$ex->getCode(),$ex];return $this->call($this->error,$this->service==null?$params:array_merge([$this->service],$params));}catch(Exception $ex){$params=[$method,$path,500,$ex];return $this->call($this->error,$this->service==null?$params:array_merge([$this->service],$params));}}}}}return $this->call($this->error,array_merge($this->service==null?[]:[$this->service],[$method,$path,404,new HttpRequestException(self::NO_ROUTE_FOUND_MSG)]));}private function call($callable,array $params=[]){if(is_string($callable)){if(strlen($callable)>0){if($callable[0]=='@'){$callable=$this->baseNamespace.substr($callable,1);}}else{throw new InvalidArgumentException('Route/error callable as string must not be empty.');}$callable=str_replace('.','\\',$callable);}if(is_array($callable)){if(count($callable)!==2)throw new InvalidArgumentException('Route/error callable as array must contain and contain only two strings.');if(strlen($callable[0])>0){if($callable[0][0]=='@'){$callable[0]=$this->baseNamespace.substr($callable[0],1);}}else{throw new InvalidArgumentException('Route/error callable as array must contain and contain only two strings.');}$callable[0]=str_replace('.','\\',$callable[0]);}return call_user_func_array($callable,$params);}public function dispatchGlobal(){$pos=strpos($_SERVER['REQUEST_URI'],'?');return $this->dispatch($_SERVER['REQUEST_METHOD'],'/'.trim(substr($pos!==false?substr($_SERVER['REQUEST_URI'],0,$pos):$_SERVER['REQUEST_URI'],strlen(implode('/',array_slice(explode('/',$_SERVER['SCRIPT_NAME']),0,-1)).'/')),'/'));}}class HttpRequestException extends Exception{}

$root=(isset($_SERVER['HTTPS']) ? "https://" : "http://").$_SERVER['HTTP_HOST'];
$root.= str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
define('root', $root);
//use AppRouter\Router;

/* 404 page init */
$router = new Router(function ($method, $path, $statusCode, $exception) {
http_response_code($statusCode);
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
echo " Wrong Request";
});

$router->post('/search', function() {

if(isset($_POST['origin']) && trim($_POST['origin']) !== "") {} else { echo "origin : LHE - param or value missing "; die; }
if(isset($_POST['destination']) && trim($_POST['destination']) !== "") {} else { echo "destination : DXB - param or value missing "; die; }
// if(isset($_POST['return_date']) && trim($_POST['return_date']) !== "") {} else { echo "return_date : 10-10-2021 - param or value missing "; die; }
if(isset($_POST['departure_date']) && trim($_POST['origin']) !== "") {} else { echo "departure_date : 10-10-2021 - param or value missing "; die; }
if(isset($_POST['adults']) && trim($_POST['adults']) !== "") {} else { echo "adults : 1 - param or value missing "; die; }
if(isset($_POST['childrens']) && trim($_POST['childrens']) !== "") {} else { echo "childrens : 1 - param or value missing "; die; }
if(isset($_POST['infants']) && trim($_POST['infants']) !== "") {} else { echo "infants : 1 - param or value missing "; die; }
if(isset($_POST['evn']) && trim($_POST['evn']) !== "") {} else { echo "evn - param or value missing "; die; }
if(isset($_POST['currency']) && trim($_POST['currency']) !== "") {} else { echo "currency : USD - param or value missing "; die; }
if(isset($_POST['type']) && trim($_POST['type']) !== "") {} else { echo "type : oneway | return - param or value missing "; die; }
if(isset($_POST['c1']) && trim($_POST['c1']) !== "") {} else { echo "c1 - param or value missing "; die; }
if(isset($_POST['c2']) && trim($_POST['c2']) !== "") {} else { echo "c2 - param or value missing "; die; }

if (isset($_POST['evn']) && $_POST['evn'] == 'pro') {
  $end_pointv1 = 'https://apihub-uat.aerticket-it.de/api/v1/search';
}else{
  $end_pointv1 = 'https://apihub-uat.aerticket-it.de/api/v1/search';
}

$login = $_POST['c1'];
$password = $_POST['c2'];

/*flight date & time*/
$departure_y = strtoupper(date('Y',strtotime($_POST['departure_date'])));
$departure_m = strtoupper(date('m',strtotime($_POST['departure_date'])));
$departure_d = strtoupper(date('d',strtotime($_POST['departure_date'])));
$return_y= strtoupper(date('Y',strtotime($_POST['return_date'])));
$return_m = strtoupper(date('m',strtotime($_POST['return_date'])));
$return_d = strtoupper(date('d',strtotime($_POST['return_date'])));
/*end flight date & time*/

/*flight route type*/
$route_data = [];
if ($_POST['type'] == 'oneway') {
    array_push($route_data,(object)array(
    				"departure" => array(
    						'iata'=>$_POST['origin'],
    						'geoObjectType'=>'AIRPORT'
    				),
    				"destination" => array(
    						'iata'=>$_POST['destination'],
    						'geoObjectType'=>'CITY'
    				),
    				'departureDate'=>array(
    						'year'=> intval($departure_y),
    						'month'=> intval($departure_m),
    						'day'=> intval($departure_d)
    				),
    				'viaExcluded'=>array(),
    				'viaIncluded'=>array()
        ));
}
if ($_POST['type'] == 'round' || $_POST['type'] == 'return') {
    array_push($route_data,(object)array(
    				"departure" => array(
    						'iata'=>$_POST['origin'],
    						'geoObjectType'=>'AIRPORT'
    				),
    				"destination" => array(
    						'iata'=>$_POST['destination'],
    						'geoObjectType'=>'CITY'
    				),
    				'departureDate'=>array(
    						'year'=> intval($departure_y),
    						'month'=> intval($departure_m),
    						'day'=> intval($departure_d)
    				),
    				'viaExcluded'=>array(),
    				'viaIncluded'=>array()
        ));

        array_push($route_data,(object)array(
    				"departure" => array(
    						'iata'=>$_POST['destination'],
    						'geoObjectType'=>'AIRPORT'
    				),
    				"destination" => array(
    						'iata'=>$_POST['origin'],
    						'geoObjectType'=>'CITY'
    				),
    				'departureDate'=>array(
    						'year'=> intval($return_y),
    						'month'=> intval($return_m),
    						'day'=> intval($return_d)
    				),
    				'viaExcluded'=>array(),
    				'viaIncluded'=>array()
        ));
} 
/*end flight route type*/

$total_adults = $_POST['adults'];
$total_childrens = $_POST['childrens'];
$total_infants = $_POST['infants'];
/*travelers details*/
$travelers_details = [];
if ($_POST['adults']) {
        array_push($travelers_details,(object)array(
            "passengerTypeCode"=> 'ADT',
            "count"=> intval($total_adults),

        ));

}

if ($_POST['childrens']) {
        array_push($travelers_details,(object)array(
            "passengerTypeCode"=> 'CHD',
            "count"=> intval($total_childrens),

        ));

}

if ($_POST['infants']) {
        array_push($travelers_details,(object)array(
            "passengerTypeCode"=> 'INF',
            "count"=> intval($total_infants),

        ));
}
/*end travelers details*/

$dynamic_search_data = array(
        'segmentList'=> $route_data,
        'requestPassengerTypeList'=> $travelers_details,
        'searchOptions'=> array(
        	'cabinClassList'=> array(
        		strtoupper($_POST['class_trip'])
        	),
        	'airlineAllianceList'=>array(),
        	'nonStopFlightsOnly'=>false,
        	'directFlightsOnly'=>false,
        	'includedAirlineList'=>array(),
        	'excludedAirlineList'=>array(),
        	// 'maxFares'=>3,
        	'fareSourceList'=>array(
        		array(
        		'id'=>'FSC_IATA'
        	),
        		array(
      			'id'=>'FSC_NEGO'
      		),
         		array(
      			'id'=>'FSC_CONSO'
      		),
         		array(
      			'id'=>'FSC_WEB'
      		),

        	),
        	'closedUserGroupTypeList'=>array(
        		array(
        			'code'=>'ALL'
        		)
        	),
        	'connectingTimeFilter'=>array(
        		'allowAirportChange'=>true
        	),
        	'needBaggage'=>false
        ),
    );

// print_r(json_encode($dynamic_search_data)); exit();

$curl = curl_init();
curl_setopt_array($curl, array(
  CURLOPT_URL => $end_pointv1,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>json_encode($dynamic_search_data),
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json',
    'login: '.$login.'',
    'password: '.$password.''
  ),
));

$response = curl_exec($curl);

curl_close($curl);
// echo $response; exit();

$decode_res = json_decode($response);
/*api pattren*/
$main_array = array();
$object_array = array();
foreach ($decode_res->availableFareList as $key) {

		foreach ($key->passengerTypeFareList as $price) {
			if ($price->passengerTypeCode == 'ADT') {
				$adults_price = $price->count*$price->priceList[0]->value+$price->priceList[1]->value+$price->priceList[2]->value;
			}
			if ($price->passengerTypeCode == 'CHD') {
				$childrens_price = $price->count*$price->priceList[0]->value+$price->priceList[1]->value+$price->priceList[2]->value;
			}
			if ($price->passengerTypeCode == 'INF') {
				$infants_price = $price->count*$price->priceList[0]->value+$price->priceList[1]->value+$price->priceList[2]->value;
			}
		}

	foreach ($key->legList as $legList_key) {
		
		foreach ($legList_key->itineraryList as $itineraryList_key) {
			// echo "<pre>"; print_r($itineraryList_key->segmentList);
			$flight_no = 0;
			$test_array = array();
			foreach ($itineraryList_key->segmentList as $segment) {

				$departure_time = $itineraryList_key->segmentList[$flight_no]->departureTimeOfDay->hour.':'.$itineraryList_key->segmentList[$flight_no]->departureTimeOfDay->minute;
				$departure_date = $itineraryList_key->segmentList[$flight_no]->departureDate->year.'-'.$itineraryList_key->segmentList[$flight_no]->departureDate->month.'-'.$itineraryList_key->segmentList[$flight_no]->departureDate->day;

				$arrival_time = $itineraryList_key->segmentList[$flight_no]->arrivalTimeOfDay->hour.':'.$itineraryList_key->segmentList[$flight_no]->arrivalTimeOfDay->minute;
				$arrival_date = $itineraryList_key->segmentList[$flight_no]->arrivalDate->year.'-'.$itineraryList_key->segmentList[$flight_no]->arrivalDate->month.'-'.$itineraryList_key->segmentList[$flight_no]->arrivalDate->day;

				$departure_code = $itineraryList_key->segmentList[$flight_no]->departure->iata;
				$departure_airport = $itineraryList_key->segmentList[$flight_no]->departure->name;

				$arrival_code = $itineraryList_key->segmentList[$flight_no]->destination->iata;
				$arrival_airport = $itineraryList_key->segmentList[$flight_no]->destination->name;

				$airline_name = $itineraryList_key->segmentList[$flight_no]->marketingAirline->name;
				$img = $itineraryList_key->segmentList[$flight_no]->marketingAirline->iata;

			array_push($test_array, (object)array(
              'departure_flight_no'=> $itineraryList_key->segmentList[$flight_no]->flightNumber,
              'img'=> 'https://travelapi.co/modules/global/resources/flights/airlines/'.$img.'.png',
              'departure_time'=> date('H:i',strtotime($departure_time)),
              'departure_date'=> date('d-m-Y',strtotime($departure_date)),
              'arrival_time'=> date('H:i',strtotime($arrival_time)),
              'arrival_date'=> date('d-m-Y',strtotime($arrival_date)),
              'departure_code'=> $departure_code,
              'departure_airport'=> $departure_airport,
              'arrival_code'=> $arrival_code,
              'arrival_airport'=> $arrival_airport,
              'duration_time'=> date('H:i', mktime(0,$itineraryList_key->flyingTimeInMinutes)),
              'currency_code'=> '',
              'adult_price'=> number_format($adults_price),
              'child_price'=> number_format($childrens_price),
              'infant_price'=> number_format($infants_price),
              'price'=> number_format($adults_price+$childrens_price+$infants_price),
              'url'=> '',
              'airline_name'=> $airline_name,
              'class_type'=> $segment->cabinClass,
              'type'=> '',
              // 'form'=> array($key),
              'form'=> '',
              'form_name'=> '',
              'action'=> '',
              'supplier'=> 'aerticket',
				));
			$flight_no++; }

		}
		    array_push($object_array, $test_array) ;
            $test_array = [];
	}
    $main_array[]["segments"] = $object_array;
    $object_array = [];
}
/*end api pattren*/
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
if (!empty($main_array)) {
  echo json_encode($main_array);
}else{
  echo json_encode([array('msg'=>'no_result')]);
}

});

$router->dispatchGlobal();