<?php

$api_result = file_get_contents('http://localhost/aerticket_format/aerticket_booking.json');


$ticket_booking_res = json_decode($api_result);
echo "<pre>"; print_r($ticket_booking_res->bookingData->locator); exit();
// echo "<pre>"; print_r(); exit();

$ticket_booking_arr = [];
if ($ticket_booking_res->bookingData->locator) {
	$ticket_booking_arr = [
        'bookingData'=>array(
            'locator'=>$ticket_booking_res->bookingData->locator
        )
    ];

}else{
    echo json_encode(['msg'=>'something wrong!','status'=>false]); exit; 
}
