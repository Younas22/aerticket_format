<?php 
    
$api_result = file_get_contents('http://localhost/aerticket_format/oneway.json');


$decode_res = json_decode($api_result);
// echo "<pre>"; print_r($api_result); exit();
// echo "<pre>"; print_r($key->legList); exit();

/*api pattren*/
$main_array = array();
$object_array = array();
foreach ($decode_res->availableFareList as $key) {

        foreach ($key->passengerTypeFareList as $price) {
            if ($price->passengerTypeCode == 'ADT') {
                $adults_price = $price->count*$price->priceList[0]->value+$price->priceList[1]->value+$price->priceList[2]->value;
            }
            if ($price->passengerTypeCode == 'CHD') {
                $childrens_price = $price->count*$price->priceList[0]->value+$price->priceList[1]->value+$price->priceList[2]->value;
            }
            if ($price->passengerTypeCode == 'INF') {
                $infants_price = $price->count*$price->priceList[0]->value+$price->priceList[1]->value+$price->priceList[2]->value;
            }
        }

    foreach ($key->legList as $legList_key) {
        
        foreach ($legList_key->itineraryList as $itineraryList_key) {
        	$test_array = array();
            // echo "<pre>"; print_r($itineraryList_key->segmentList);
            $flight_no = 0;
            foreach ($itineraryList_key->segmentList as $segment) {

                $departure_time = $itineraryList_key->segmentList[$flight_no]->departureTimeOfDay->hour.':'.$itineraryList_key->segmentList[$flight_no]->departureTimeOfDay->minute;
                $departure_date = $itineraryList_key->segmentList[$flight_no]->departureDate->year.'-'.$itineraryList_key->segmentList[$flight_no]->departureDate->month.'-'.$itineraryList_key->segmentList[$flight_no]->departureDate->day;

                $arrival_time = $itineraryList_key->segmentList[$flight_no]->arrivalTimeOfDay->hour.':'.$itineraryList_key->segmentList[$flight_no]->arrivalTimeOfDay->minute;
                $arrival_date = $itineraryList_key->segmentList[$flight_no]->arrivalDate->year.'-'.$itineraryList_key->segmentList[$flight_no]->arrivalDate->month.'-'.$itineraryList_key->segmentList[$flight_no]->arrivalDate->day;

                $departure_code = $itineraryList_key->segmentList[$flight_no]->departure->iata;
                $departure_airport = $itineraryList_key->segmentList[$flight_no]->departure->name;

                $arrival_code = $itineraryList_key->segmentList[$flight_no]->destination->iata;
                $arrival_airport = $itineraryList_key->segmentList[$flight_no]->destination->name;

                $airline_name = $itineraryList_key->segmentList[$flight_no]->marketingAirline->name;
                $img = $itineraryList_key->segmentList[$flight_no]->marketingAirline->iata;

          $oneway_id=end($legList_key->itineraryList)->id;
          $return_id=end(end($key->legList)->itineraryList)->id;
          if ($oneway_id == $return_id) {
              $return_id = null;
          }
            array_push($test_array, (object)array(
              'departure_flight_no'=> $itineraryList_key->segmentList[$flight_no]->flightNumber,
              'img'=> 'https://travelapi.co/modules/global/resources/flights/airlines/'.$img.'.png',
              'departure_time'=> date('H:i',strtotime($departure_time)),
              'departure_date'=> date('d-m-Y',strtotime($departure_date)),
              'arrival_time'=> date('H:i',strtotime($arrival_time)),
              'arrival_date'=> date('d-m-Y',strtotime($arrival_date)),
              'departure_code'=> $departure_code,
              'departure_airport'=> $departure_airport,
              'arrival_code'=> $arrival_code,
              'arrival_airport'=> $arrival_airport,
          'duration_time'=> date('H:i', mktime(0,$itineraryList_key->flyingTimeInMinutes)),
              'currency_code'=> '',
              'adult_price'=> number_format($adults_price),
              'child_price'=> number_format($childrens_price),
              'infant_price'=> number_format($infants_price),
              'price'=> number_format($adults_price+$childrens_price+$infants_price),
              'url'=> '',
              'airline_name'=> $airline_name,
              'class_type'=> $segment->cabinClass,
              'type'=> '',
              'form'=> array(
                'fareId'=>$key->fareId,
                'oneway_id'=>$oneway_id,
                'return_id'=>$return_id,
                ),
              'form_name'=> '',
              'action'=> '',
              'supplier'=> 'aerticket',
                ));
            $flight_no++; }

        }
            array_push($object_array, $test_array) ;
            $test_array = [];
    }
    $main_array[]["segments"] = $object_array;
    $object_array = [];
}
/*end api pattren*/
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
echo json_encode($main_array);
?>